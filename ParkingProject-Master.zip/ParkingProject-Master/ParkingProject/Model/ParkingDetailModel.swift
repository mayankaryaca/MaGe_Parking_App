//
//  ParkingDetailModel.swift
//  ParkingProject
//
//  Created by Mayank Arya on 2021-05-14.
//
// Gerin Puig - 101343659
// Mayank Arya - 101300566

import Foundation

class parking{
    
    var headerLabel : String
    var detailLabel : String
    
    init(headerLabel : String, detailLabel : String){
        self.headerLabel = headerLabel
        self.detailLabel = detailLabel
    }
}
