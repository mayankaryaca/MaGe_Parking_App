//
//  parkingViewCell.swift
//  ParkingProject
//
//  Created by Mayank Arya on 2021-05-13.
//

import UIKit

class parkingViewCell : UITableViewCell{
    
}
